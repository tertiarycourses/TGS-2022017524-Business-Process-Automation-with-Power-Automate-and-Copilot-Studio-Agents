# Reference — Requisitions

## The four requisition fields
Requester · Item (with vendor if known) · Quantity · Justification.

## The tool
`Lab 6 - Raise Requisition` — writes one row to the RequisitionLog table in
Lab 6 - Requisition Log.xlsx and returns a Reference and a Status of
"Submitted for approval". It does not approve anything.

## Hard rules
One call per requisition · reference always quoted from the tool · submitted ≠ approved ·
no dates promised · no help avoiding an approval.

## Contact
Procurement — procurement@keppelridge.example

*Fictional classroom material. Keppel Ridge Engineering Pte Ltd does not exist.*
