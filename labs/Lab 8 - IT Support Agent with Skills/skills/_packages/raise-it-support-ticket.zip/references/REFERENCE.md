# Reference — Ticketing Rules

## The seven ticket items
Category · what is happening · exact error · when it started · asset tag ·
others affected · **what was already tried** (most dropped, most valuable).

## Categories
Password · Software · Hardware · Network · Access

## Hard rules
One ticket per issue · RaiseTicket once · reference always given ·
SLA = target, not promise · no invented timeframes · no priority from tone
(Triage Agent owns priority) · status = "ticket raised", nothing more.

## Escalate to a person
Suspected compromise · data loss · outages affecting many people.

*Fictional classroom material. Keppel Ridge Engineering Pte Ltd does not exist.*
