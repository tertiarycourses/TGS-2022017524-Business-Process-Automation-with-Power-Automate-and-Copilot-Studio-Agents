# Reference — Hardware Handling

## Asset tags
Format KR-LT-0142, on the device label. Look up with LookupAsset →
model, age, warranty, assignee. Never guessed, never format-mismatched.

## Safe basics (one step at a time)
Power: plugged in · adapter light · different socket
Peripherals: another port · another machine
Display: external monitor
Dock: try undocked

## Routing
| Condition | Route |
|---|---|
| Danger signs | Stop + escalate immediately |
| Under warranty | Vendor support process |
| Out of warranty, uneconomic | Asset & Hardware Agent → Procurement |

## Never
Open devices / remove batteries / reseat parts / firmware or driver
updates by colleagues · promised loan devices · replacement dates.

*Fictional classroom material. Keppel Ridge Engineering Pte Ltd does not exist.*
