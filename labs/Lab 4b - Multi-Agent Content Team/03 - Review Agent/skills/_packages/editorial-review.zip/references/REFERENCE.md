# Reference — The Four Checks

| # | Check | Fails when | Stop? |
|---|---|---|---|
| 1 | Facts | Any course fact not in the brief, fee/duration not word-for-word, or "Not established" material used | Yes — skip rest |
| 2 | Claims | Prices/discounts beyond brief · employment/income/mastery promises · competitor comparisons | Yes — skip rest |
| 3 | Voice | Not second person · dishonest about difficulty · banned words (hack, unleash, elevate, journey, world-class, guru, limited time) | No |
| 4 | Shape | Outside 500–700 words · title not problem-led · headings sparser than ~150 words · ≠ 1 CTA | No |

## Verdict rules
Clean draft → "Recommend approval" (never "approved") · every finding
quotes the failing words, names the check, states what the brief says ·
"For the human" always names the weakest point.

*Fictional classroom material. Cook & Bake Academy does not exist.*
