# Reference — Research Brief Rules

## The five sections (exact order)
1. Task · 2. Course facts (from the brochures) · 3. Audience notes (from
the web) · 4. Suggested angle · 5. Not established

## Hard rules
- ≤ 350 words; working material, not the article.
- Facts only from brochures; fees/durations quoted exactly; each fact
  names its brochure.
- Unknown course → stop after section 2.
- Audience notes: web-sourced, no Academy claims.
- Angle: honest = built only on section 2.
- "Not established" is the anti-hallucination fence for the whole pipeline.

## Downstream consumers
Blog Agent writes only from sections 2–4 · Review Agent fails any draft
using section 5 material.

*Fictional classroom material. Cook & Bake Academy does not exist.*
