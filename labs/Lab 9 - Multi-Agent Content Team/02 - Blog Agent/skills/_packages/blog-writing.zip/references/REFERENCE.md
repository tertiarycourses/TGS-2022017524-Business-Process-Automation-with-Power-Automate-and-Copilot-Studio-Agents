# Reference — Blog Shape Rules

## Shape
| Element | Rule |
|---|---|
| Length | 500–700 words (over → cut weakest section) |
| Title | Reader's problem/occasion, not the school |
| Opening | 2–3 sentences from audience notes; no school yet |
| Body | One idea per section; heading ~every 150 words |
| Course facts | Only from the brief, word for word |
| CTA | Exactly one, at the end, naming one course |

## Banned words
hack · unleash · elevate · journey · world-class · guru · limited time

## Pre-handback checks (fix, don't list)
Facts match brief word for word · nothing from "Not established" · word
count in band · one CTA · no banned words.

*Fictional classroom material. Cook & Bake Academy does not exist.*
