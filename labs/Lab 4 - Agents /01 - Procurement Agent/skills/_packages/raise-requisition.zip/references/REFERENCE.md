# Reference — Requisition Routing

## The nine requisition fields
Requester, Department, Vendor, Item description, Unit price (SGD),
Quantity, Competing quotes, Budget code, Needed by.

## Routing rules (evaluated in order; first match wins)
| Step | Condition | Routing | Flag |
|---|---|---|---|
| 1 | Vendor not on register | BLOCKED | UNAPPROVED_VENDOR |
| 1 | Vendor Suspended | BLOCKED | VENDOR_SUSPENDED |
| 1 | Vendor Under Review | APPROVAL | VENDOR_UNDER_REVIEW |
| 2 | < 3 quotes and total ≥ SGD 5,000 | APPROVAL | SINGLE_SOURCE |
| 3 | Capital expenditure and total ≥ SGD 2,000 | APPROVAL | CAPEX |
| 4 | Total ≥ SGD 10,000 | APPROVAL | ABOVE_THRESHOLD |
| — | None of the above | AUTO | — |

Capital-expenditure categories: IT Hardware, Machinery, Vehicles, Facilities.
Consumable categories: Stationery, PPE, Consumables, Software Subscription.

## Contact
Procurement — procurement@keppelridge.example

*Fictional classroom material. Keppel Ridge Engineering Pte Ltd does not exist.*
