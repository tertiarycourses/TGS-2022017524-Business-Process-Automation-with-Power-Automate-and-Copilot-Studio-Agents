# Reference — Vendor Register

## Statuses
| Status | Meaning |
|---|---|
| Approved | May be purchased from. |
| Suspended | New requisitions blocked. |
| Under Review | Purchases only with approval. |

A vendor absent from the register has not been assessed and may not be
purchased from — absence is not a judgement about quality.

**Registered is not the same as approved.** A vendor with a signed master
agreement may still be a vendor you cannot buy from this week.

## Disclosure rule
Report only two things: whether the vendor may be used, and its approved
category. Never disclose which non-usable status applies, or the Notes field.

## Contact
Procurement — procurement@keppelridge.example

*Fictional classroom material. Keppel Ridge Engineering Pte Ltd does not exist.*
