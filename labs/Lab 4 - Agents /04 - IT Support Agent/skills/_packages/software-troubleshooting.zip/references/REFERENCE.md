# Reference — Software Support

## Diagnosis inputs
Application name · exact error wording · when it started · what changed.

## Safe steps (one at a time)
Full close/reopen → restart device → (Office) web version → another file.

## Install & licence routing
| Situation | Route |
|---|---|
| In approved catalogue | Ticket — Software category |
| Not in catalogue | Access Request Agent (approval needed) |
| Any non-portal download | Never |

## Never
Registry edits · command-line fixes · safe mode · disabling antivirus ·
admin-rights steps · turning off updates/security controls.

## Security signals → escalate
Unexpected pop-ups · licence warnings for unbought software · software the
colleague didn't install.

*Fictional classroom material. Keppel Ridge Engineering Pte Ltd does not exist.*
