# Reference — Network Triage

## Scope first (in this order)
1. One site/system, or everything?
2. Colleagues nearby affected?
3. Office, home, or on site?
4. Wired, Wi-Fi, or VPN?

Known-issues log before anything else. Nearby colleagues affected → not
the device → escalate.

## Single-device steps (one at a time)
Wi-Fi off/on · confirm KeppelRidge-Corp network · restart device ·
VPN full sign-out/in · check other network locations (shared drives).

## Never
IP/DNS/adapter/firewall changes by the colleague · personal hotspots or
unsecured networks for site work.

*Fictional classroom material. Keppel Ridge Engineering Pte Ltd does not exist.*
