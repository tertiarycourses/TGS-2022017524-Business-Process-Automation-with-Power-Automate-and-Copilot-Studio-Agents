# Reference — Sign-in Problems

## The four problems behind "cannot sign in"
| Problem | Route |
|---|---|
| Forgotten password | Self-service portal |
| Locked out | Self-service portal (clears in 15 min) |
| Password expired | Ticket — Password category |
| MFA device lost/replaced | Ticket — Password category |

Self-service portal: https://passwordreset.keppelridge.example

## Never
Ask for or accept passwords, MFA codes, OTPs · claim a reset happened ·
touch another person's account · continue after a phishing signal.

*Fictional classroom material. Keppel Ridge Engineering Pte Ltd does not exist.*
