# Reference — Course Catalogue

## Baking (BAK)
101 Artisan Sourdough Bread Baking · 102 French Pastry & Viennoiserie ·
103 Wedding Cake Design & Decoration · 104 Macaron Masterclass ·
105 Chocolate & Confectionery Making · 106 Cupcake & Cake Pops Workshop ·
107 Bread Making Fundamentals · 108 Cookie & Biscuit Baking ·
109 Pie & Tart Specialist · 110 Korean & Asian Bakery

## Culinary (CUL)
201 Italian Cuisine Mastery · 202 Thai Street Food Cooking ·
203 Japanese Sushi & Sashimi · 204 French Culinary Foundations ·
205 Chinese Wok Cooking · 206 Indian Curry & Spices ·
207 Healthy Meal Prep & Nutrition · 208 Vegetarian & Vegan Cuisine ·
209 Grilling & BBQ Mastery · 210 Knife Skills & Kitchen Essentials

Fees are SGD, GST-inclusive, quoted exactly as brochured.

## Contact
+65 6888 1234 · enrol@cookbakeacademy.sg

*Fictional classroom material. Cook & Bake Academy does not exist.*
