# Reference — Enrolment Rules

## Required fields
Name · email or phone · course code · preferred intake month.

## Hard rules
- Confirm course code + fee back before creating the enquiry.
- CreateEnrolmentEnquiry exactly once; give the reference number.
- Never confirm/hold/reserve a place. Never take payment details or NRIC.
- Early bird: 10% for sign-ups ≥ 4 weeks before intake — stated, never computed.
- More than one participant → Quotation Agent.

## Contact
+65 6888 1234 · enrol@cookbakeacademy.sg

*Fictional classroom material. Cook & Bake Academy does not exist.*
