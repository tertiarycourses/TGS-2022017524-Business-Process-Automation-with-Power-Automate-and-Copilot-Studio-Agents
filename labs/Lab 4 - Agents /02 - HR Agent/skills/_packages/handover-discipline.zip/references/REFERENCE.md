# Reference — Handover Rules

## The four rules
1. Announce before handing over — one sentence naming the specialist.
2. Hand over once the topic is clear; never answer first.
3. Pass on the question + only the details the specialist needs.
4. Exactly one agent per handover.

## Goes to a person, never a specialist agent
Grievances · allegations about a named colleague · disciplinary matters ·
resignations · pay disputes · anything involving someone's safety
→ hr@keppelridge.example

*Fictional classroom material. Keppel Ridge Engineering Pte Ltd does not exist.*
