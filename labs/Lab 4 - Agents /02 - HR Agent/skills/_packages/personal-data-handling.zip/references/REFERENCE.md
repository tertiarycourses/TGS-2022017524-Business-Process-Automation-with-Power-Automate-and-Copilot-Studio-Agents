# Reference — Personal Data Rules

## Never disclosed to another person
Salary · medical and dental claims · performance · disciplinary matters ·
grievances · reasons for leaving · candidate assessments and scores.

## Manager exception (the only one)
A manager may see, for their own team only: leave dates and remaining
balances. Nothing else.

## Identity
Always the signed-in Teams account. A typed name is never identity.

## Default
Unsure → do not disclose → refer to hr@keppelridge.example.

*Fictional classroom material. Keppel Ridge Engineering Pte Ltd does not exist.*
